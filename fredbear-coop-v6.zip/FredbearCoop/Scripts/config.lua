-- ============================================================
--  RÉGLAGES DU MOD FREDBEARCOOP (v6)
--  true = activé, false = désactivé
-- ============================================================
return {
    -- "host" sur le PC qui héberge (sa nuit fait foi), "client" sur l'autre
    ROLE = "host",

    -- IP Radmin de l'hôte (sert seulement à la touche F9)
    HOST_IP = "26.0.0.1",

    -- ---------- INTERRUPTEURS ----------
    -- Si le jeu plante, mets-les tous à false, puis rallume-les un par un.
    SYNC_ENABLED      = true,   -- interrupteur général de la synchro
    SYNC_POSITIONS    = true,   -- position des animatroniques (hôte -> client)
    SYNC_VARIABLES    = true,   -- portes, batterie, heure... (hôte <-> client)
    SCAN_ALL_ACTORS   = false,  -- chercher aussi les portes/lumières dans TOUS les objets (plus lourd)
    FREEZE_CLIENT_AI  = true,   -- client : couper l'IA locale des animatroniques
    SHOW_MARKER       = true,   -- fantôme (corps gris + lumière verte) là où est l'autre joueur
    KEYBINDS          = true,   -- touches F3 à F9

    -- ---------- SÉCURITÉ ----------
    -- Le mod ne fait RIEN tant que tu n'es pas dans une nuit depuis ce nombre de secondes
    START_DELAY_S = 15,

    -- Si le nom de la map contient un de ces mots, c'est un menu : le mod ne fait rien
    MENU_WORDS = { "menu", "title", "intro", "loading", "lobby", "start", "credits" },

    -- ---------- VITESSE ----------
    TICK_MS    = 100,  -- positions : 10 fois par seconde
    VARS_EVERY = 3,    -- variables : toutes les 3 boucles
    DISCOVER_S = 10,   -- re-cherche des objets toutes les 10 secondes

    -- Mots-clés pour reconnaître les objets importants (en minuscules)
    KEYWORDS = {
        "anim", "fred", "bonnie", "chica", "foxy", "spring", "golden", "bear",
        "enemy", "monster", "door", "porte", "light", "flash", "power",
        "battery", "energy", "clock", "hour", "night", "vent", "mask",
        "manager", "gamemode", "gamestate", "jumpscare",
    },

    -- Écrire chaque étape dans la console / UE4SS.log (pour trouver un crash)
    VERBOSE = true,
}
