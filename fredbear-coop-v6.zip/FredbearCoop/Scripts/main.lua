--[[
  FredbearCoop v6 - mod UE4SS pour Those Nights at Fredbear's

  Différences avec la v2 (qui faisait "Fatal error") :
    - le mod ne fait RIEN au lancement ni dans les menus ;
    - il attend d'être dans une nuit depuis START_DELAY_S secondes ;
    - plus d'apparition de lumière par défaut (SHOW_MARKER = false) ;
    - plus de scan de tous les objets par défaut (SCAN_ALL_ACTORS = false) ;
    - les déplacements utilisent K2_TeleportTo (pas de paramètre "HitResult") ;
    - chaque fonction a son interrupteur dans config.lua ;
    - chaque étape est écrite dans UE4SS.log : si ça plante encore,
      la dernière ligne "[FredbearCoop]" du log dit où.

  Touches : F3 test lumière | F4 lumière ON/OFF | F5 rapport | F6 état | F7 synchro ON/OFF | F8 héberger | F9 rejoindre
]]

local okCfg, cfg = pcall(require, "config")
if not okCfg then
    print("[FredbearCoop] config.lua illisible : " .. tostring(cfg) .. "\n")
    return
end

local IS_HOST = (cfg.ROLE == "host")
local TMP = os.getenv("TEMP") or os.getenv("TMP") or "."
local OUT_FILE = TMP .. "\\fredbear_coop_local.txt"
local IN_FILE  = TMP .. "\\fredbear_coop_remote.txt"
local DESKTOP  = (os.getenv("USERPROFILE") or TMP) .. "\\Desktop"

----------------------------------------------------------------------
-- OUTILS
----------------------------------------------------------------------
local function log(msg) print("[FredbearCoop] " .. tostring(msg) .. "\n") end
local said = {}
local function step(msg)            -- écrit une étape une seule fois dans le log
    if cfg.VERBOSE and not said[msg] then said[msg] = true log("étape : " .. msg) end
end

local function valid(o)
    if o == nil then return false end
    local ok, r = pcall(function() return o:IsValid() end)
    return ok and r
end
local function try(f, ...) local ok, r = pcall(f, ...) if ok then return r end return nil end
local function now() return os.time() end

local function fmt(v)
    if type(v) == "boolean" then return v and "1" or "0" end
    if type(v) == "number" then
        if v == math.floor(v) and math.abs(v) < 1e9 then return string.format("%d", v) end
        return string.format("%.3f", v)
    end
    return nil
end
local function parse(kind, s)
    if kind == "BoolProperty" then return s == "1" end
    return tonumber(s)
end
local function split(s, sep)
    local t = {}
    for part in string.gmatch(s, "([^" .. sep .. "]+)") do t[#t + 1] = part end
    return t
end

local classes = {}
local function cls(path)
    if not valid(classes[path]) then classes[path] = try(function() return StaticFindObject(path) end) end
    return classes[path]
end
local function isA(o, path)
    local c = cls(path)
    if not valid(c) then return false end
    return try(function() return o:IsA(c) end) == true
end
local function nameOf(o) return try(function() return o:GetFName():ToString() end) end
local function fullName(o) return try(function() return o:GetFullName() end) or "" end
local function className(o) return try(function() return o:GetClass():GetFName():ToString() end) or "" end

----------------------------------------------------------------------
-- ÉTAT DE LA PARTIE : est-on dans une nuit ?
----------------------------------------------------------------------
local game = { pawn = nil, pc = nil, map = nil, readySince = nil, ready = false }

local function currentMap(pc)
    local gs = cls("/Script/Engine.Default__GameplayStatics")
    if not valid(gs) then return nil end
    return try(function() return gs:GetCurrentLevelName(pc, true):ToString() end)
end

local function isMenu(map)
    local m = (map or ""):lower()
    for _, w in ipairs(cfg.MENU_WORDS) do
        if string.find(m, w, 1, true) then return true end
    end
    return false
end

-- Met à jour game.* ; renvoie true seulement si on est dans une nuit depuis assez longtemps
local function checkReady()
    local pc = try(function() return FindFirstOf("PlayerController") end)
    if not valid(pc) then game.ready = false game.readySince = nil return false end
    local pawn = try(function() return pc.Pawn end)
    if not valid(pawn) then game.ready = false game.readySince = nil return false end
    local map = currentMap(pc)
    if not map or map == "" or isMenu(map) then
        game.ready = false game.readySince = nil return false
    end
    if map ~= game.map then
        log("Nouvelle map : " .. map .. " -> attente de " .. cfg.START_DELAY_S .. " s avant de démarrer")
        game.map = map
        game.readySince = now()
        game.ready = false
        return false
    end
    game.pc, game.pawn = pc, pawn
    if not game.ready and game.readySince and now() - game.readySince >= cfg.START_DELAY_S then
        game.ready = true
        log("Nuit détectée (" .. map .. "), la synchro démarre")
    end
    return game.ready
end

----------------------------------------------------------------------
-- DÉCOUVERTE DES OBJETS
----------------------------------------------------------------------
local SIMPLE_TYPES = { "BoolProperty", "FloatProperty", "IntProperty", "ByteProperty", "DoubleProperty" }

local function propKind(prop)
    if not PropertyTypes then return nil end
    for _, k in ipairs(SIMPLE_TYPES) do
        local pt = PropertyTypes[k]
        if pt and try(function() return prop:IsA(pt) end) == true then return k end
    end
    return nil
end

local propCache = {}
local function propsOf(obj)
    if not cfg.SYNC_VARIABLES then return {} end
    local key = className(obj)
    if key == "" or key:sub(-2) ~= "_C" then return {} end -- seulement les Blueprints du jeu
    if propCache[key] then return propCache[key] end
    step("lecture des variables de " .. key)
    local list = {}
    -- On lit les variables de la classe ET de ses parents Blueprint
    -- (ex : BP_Fredbear_C hérite souvent d'un BP_Animatronic_Base_C qui a les variables)
    local seenProp = {}
    local c = try(function() return obj:GetClass() end)
    local depth = 0
    while valid(c) and depth < 6 do
        local cn = try(function() return c:GetFName():ToString() end) or ""
        if cn:sub(-2) ~= "_C" then break end
        pcall(function()
            c:ForEachProperty(function(prop)
                local kind = propKind(prop)
                if kind then
                    local n = try(function() return prop:GetFName():ToString() end)
                    if n and not seenProp[n] then
                        seenProp[n] = true
                        list[#list + 1] = { name = n, kind = kind }
                    end
                end
            end)
        end)
        c = try(function() return c:GetSuperStruct() end)
        depth = depth + 1
    end
    log(key .. " : " .. #list .. " variables synchronisées")
    propCache[key] = list
    return list
end

local function matchesKeyword(text)
    for _, k in ipairs(cfg.KEYWORDS) do
        if string.find(text, k, 1, true) then return true end
    end
    return false
end

local tracked = {}
local lastDiscover = 0

local function addTracked(found, a, isPawn)
    if not valid(a) then return end
    local fn = fullName(a)
    if fn:find("Default__", 1, true) then return end -- jamais les objets "modèles"
    local n = nameOf(a)
    if not n or found[n] then return end
    local old = tracked[n]
    if old and old.obj == a then found[n] = old return end
    local loc = try(function() return a:K2_GetActorLocation() end)
    found[n] = {
        obj = a, props = propsOf(a), isPawn = isPawn, cls = className(a),
        startLoc = loc and { X = loc.X, Y = loc.Y, Z = loc.Z } or nil,
        moves = isPawn,
    }
end

local function discover()
    step("recherche des objets")
    local found = {}
    local myPawn = fullName(game.pawn)

    -- 1. Les objets "chef" du niveau (souvent : batterie, heure, portes)
    for _, c in ipairs({ "LevelScriptActor", "GameModeBase", "GameStateBase" }) do
        local o = try(function() return FindFirstOf(c) end)
        if valid(o) then addTracked(found, o, false) end
    end

    -- 2. Les Pawns (animatroniques) qui ne sont pas des joueurs
    for _, p in ipairs(try(function() return FindAllOf("Pawn") end) or {}) do
        if valid(p) and fullName(p) ~= myPawn and className(p):sub(-2) == "_C" then
            local ctrl = try(function() return p.Controller end)
            if not (valid(ctrl) and isA(ctrl, "/Script/Engine.PlayerController")) then
                addTracked(found, p, true)
            end
        end
    end

    -- 3. (optionnel) tous les objets Blueprint dont le nom contient un mot-clé
    if cfg.SCAN_ALL_ACTORS then
        step("scan complet des objets")
        for _, a in ipairs(try(function() return FindAllOf("Actor") end) or {}) do
            if valid(a) then
                local c = className(a)
                if c:sub(-2) == "_C" and matchesKeyword((c .. " " .. (nameOf(a) or "")):lower()) then
                    addTracked(found, a, false)
                end
            end
        end
    end

    tracked = found
    step("recherche terminée")
end

----------------------------------------------------------------------
-- FANTÔME DE L'AUTRE JOUEUR : un corps (cylindre gris) + une lumière verte
----------------------------------------------------------------------
local function moveActor(obj, loc, rot)
    -- K2_TeleportTo n'a pas de paramètre de sortie : plus sûr que K2_SetActorLocation
    pcall(function() obj:K2_TeleportTo(loc, rot) end)
end

local markerOn = cfg.SHOW_MARKER   -- (bug v5 : cette variable était déclarée trop bas)
local ghost = { body = nil, light = nil }
local testUntil = 0                -- F3 : on montre le fantôme devant soi pendant 4 s

local function spawnActor(classPath, at)
    local gs = cls("/Script/Engine.Default__GameplayStatics")
    local c = cls(classPath)
    if not valid(gs) or not valid(c) or not valid(game.pawn) then return nil end
    local t = {
        Rotation = { X = 0, Y = 0, Z = 0, W = 1 },
        Translation = { X = at.X, Y = at.Y, Z = at.Z },
        Scale3D = { X = 1, Y = 1, Z = 1 },
    }
    local a = try(function() return gs:BeginDeferredActorSpawnFromClass(game.pawn, c, t, 1, game.pawn) end)
    if not valid(a) then return nil end
    pcall(function() gs:FinishSpawningActor(a, t) end)
    return a
end

local function findBodyMesh()
    local paths = {
        "/Engine/BasicShapes/Cylinder.Cylinder",
        "/Engine/BasicShapes/Cube.Cube",
        "/Engine/EngineMeshes/Cylinder.Cylinder",
        "/Engine/EngineMeshes/Sphere.Sphere",
    }
    for _, p in ipairs(paths) do
        local m = try(function() return StaticFindObject(p) end)
        if not valid(m) and LoadAsset then m = try(function() return LoadAsset(p) end) end
        if valid(m) then return m, p end
    end
    return nil
end

local function spawnGhost(at)
    step("création du fantôme de l'autre joueur")
    -- 1. Le corps
    local body = spawnActor("/Script/Engine.StaticMeshActor", at)
    if valid(body) then
        local mesh, path = findBodyMesh()
        local comp = try(function() return body.StaticMeshComponent end)
        if valid(comp) and mesh then
            pcall(function() comp:SetMobility(2) end)
            pcall(function() comp:SetStaticMesh(mesh) end)
            pcall(function() comp:SetCollisionEnabled(0) end)
            pcall(function() body:SetActorScale3D({ X = 0.6, Y = 0.6, Z = 1.8 }) end)
            log("Corps du fantôme : " .. path)
        else
            log("Pas de forme trouvée pour le corps, seulement la lumière")
        end
    end
    -- 2. La lumière verte au-dessus
    local light = spawnActor("/Script/Engine.PointLight", at)
    local l = valid(light) and try(function() return light.PointLightComponent end)
    if valid(l) then
        pcall(function() l:SetMobility(2) end)
        pcall(function() l:SetIntensity(5000.0) end)
        pcall(function() l:SetLightColor({ R = 0.1, G = 1.0, B = 0.2, A = 1.0 }, true) end)
        pcall(function() l:SetAttenuationRadius(300.0) end)
    end
    ghost.body, ghost.light = body, light
end

local function placeGhost(at)
    if not valid(ghost.body) and not valid(ghost.light) then spawnGhost(at) end
    local rot = { Pitch = 0, Yaw = 0, Roll = 0 }
    -- le centre d'un joueur est à ~90 cm du sol : le cylindre (180 cm) est centré dessus
    if valid(ghost.body) then moveActor(ghost.body, { X = at.X, Y = at.Y, Z = at.Z - 90 }, rot) end
    if valid(ghost.light) then moveActor(ghost.light, { X = at.X, Y = at.Y, Z = at.Z + 110 }, rot) end
    return valid(ghost.body) or valid(ghost.light)
end

----------------------------------------------------------------------
-- SYNCHRO
----------------------------------------------------------------------
local enabled = cfg.SYNC_ENABLED
local tick, seq = 0, 0
local remote = { seq = -1, time = 0, player = nil }
local lastApplied, pending, frozen = {}, {}, {}
local stats = { sentA = 0, sentV = 0, gotA = 0, gotV = 0, gotC = 0 }
local lastLog = 0

local function readIncoming()
    local f = io.open(IN_FILE, "r")
    if not f then return nil end
    local data = f:read("*a")
    f:close()
    if not data or data == "" then return nil end
    local lines = split(data, "\n")
    local head = split(lines[1] or "", "\t")
    if head[1] ~= "S" then return nil end
    local s = tonumber(head[2])
    if not s or s == remote.seq then return nil end
    remote.seq, remote.time = s, now()
    return lines
end

local function getVar(obj, prop) return try(function() return obj[prop] end) end
local function setVar(obj, prop, value) pcall(function() obj[prop] = value end) end


local function freezeAI(e, n)
    if frozen[n] or not cfg.FREEZE_CLIENT_AI or not e.isPawn then return end
    frozen[n] = true
    step("coupure de l'IA locale")
    pcall(function()
        local c = e.obj.Controller
        if valid(c) and valid(c.BrainComponent) then c.BrainComponent:StopLogic("FredbearCoop") end
    end)
end

local function applyIncoming(lines)
    for i = 2, #lines do
        local p = split(lines[i], "\t")
        local kind = p[1]
        if kind == "P" and #p >= 4 then
            remote.player = { X = tonumber(p[2]), Y = tonumber(p[3]), Z = tonumber(p[4]) }

        elseif kind == "A" and not IS_HOST and cfg.SYNC_POSITIONS and #p >= 8 then
            local e = tracked[p[2]]
            if e and valid(e.obj) then
                step("déplacement d'un animatronique")
                moveActor(e.obj,
                    { X = tonumber(p[3]), Y = tonumber(p[4]), Z = tonumber(p[5]) },
                    { Pitch = tonumber(p[6]), Yaw = tonumber(p[7]), Roll = tonumber(p[8]) })
                freezeAI(e, p[2])
                stats.gotA = stats.gotA + 1
            end

        elseif kind == "V" and not IS_HOST and cfg.SYNC_VARIABLES and #p >= 5 then
            local e = tracked[p[2]]
            if e and valid(e.obj) then
                step("application d'une variable de l'hôte")
                local key, hostVal = p[2] .. "." .. p[3], p[5]
                local mine = fmt(getVar(e.obj, p[3]))
                if p[4] == "BoolProperty" and lastApplied[key] ~= nil
                   and mine ~= nil and mine ~= lastApplied[key] and mine ~= hostVal then
                    pending[key] = { obj = p[2], prop = p[3], kind = p[4], value = mine, t = now() }
                elseif not pending[key] or pending[key].value == hostVal or now() - pending[key].t > 2 then
                    pending[key] = nil
                    if mine ~= hostVal then setVar(e.obj, p[3], parse(p[4], hostVal)) end
                    lastApplied[key] = hostVal
                end
                stats.gotV = stats.gotV + 1
            end

        elseif kind == "C" and IS_HOST and cfg.SYNC_VARIABLES and #p >= 5 then
            local e = tracked[p[2]]
            if e and valid(e.obj) then
                step("application d'un changement du client")
                setVar(e.obj, p[3], parse(p[4], p[5]))
                stats.gotC = stats.gotC + 1
            end
        end
    end
end

local function buildOutgoing()
    seq = seq + 1
    local out = { "S\t" .. seq .. "\t" .. cfg.ROLE }
    local l = try(function() return game.pawn:K2_GetActorLocation() end)
    if l then out[#out + 1] = string.format("P\t%.1f\t%.1f\t%.1f", l.X, l.Y, l.Z) end

    if IS_HOST then
        local sendVars = cfg.SYNC_VARIABLES and (tick % cfg.VARS_EVERY) == 0
        for n, e in pairs(tracked) do
            if valid(e.obj) then
                if cfg.SYNC_POSITIONS then
                    local al = try(function() return e.obj:K2_GetActorLocation() end)
                    if al then
                        if not e.moves and e.startLoc then
                            local d = math.abs(al.X - e.startLoc.X) + math.abs(al.Y - e.startLoc.Y) + math.abs(al.Z - e.startLoc.Z)
                            if d > 5 then e.moves = true end
                        end
                        if e.moves then
                            local r = try(function() return e.obj:K2_GetActorRotation() end)
                            if r then
                                out[#out + 1] = string.format("A\t%s\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f",
                                    n, al.X, al.Y, al.Z, r.Pitch, r.Yaw, r.Roll)
                                stats.sentA = stats.sentA + 1
                            end
                        end
                    end
                end
                if sendVars then
                    for _, pr in ipairs(e.props) do
                        local v = fmt(getVar(e.obj, pr.name))
                        if v then
                            out[#out + 1] = "V\t" .. n .. "\t" .. pr.name .. "\t" .. pr.kind .. "\t" .. v
                            stats.sentV = stats.sentV + 1
                        end
                    end
                end
            end
        end
    else
        for _, c in pairs(pending) do
            out[#out + 1] = "C\t" .. c.obj .. "\t" .. c.prop .. "\t" .. c.kind .. "\t" .. c.value
        end
    end
    return table.concat(out, "\n") .. "\nE"
end

local idle = 0
local function syncStep()
    -- Hors d'une nuit : on vérifie seulement une fois par seconde environ
    if not game.ready then
        idle = idle + 1
        if idle % math.max(1, math.floor(1000 / cfg.TICK_MS)) ~= 1 then return end
    end
    if not checkReady() then return end
    tick = tick + 1
    step("première boucle de synchro")

    if now() - lastDiscover >= cfg.DISCOVER_S then
        lastDiscover = now()
        discover()
    end

    local lines = readIncoming()
    if lines then applyIncoming(lines) end

    local data = buildOutgoing()
    -- Toutes les 10 s, un résumé dans la console pour voir si la synchro passe
    if now() - lastLog >= 10 then
        lastLog = now()
        local count = 0
        for _ in pairs(tracked) do count = count + 1 end
        local rp = remote.player
        log(string.format("[%s] animatroniques=%d | envoyés anim=%d var=%d | reçus anim=%d var=%d chg=%d",
            cfg.ROLE, count, stats.sentA, stats.sentV, stats.gotA, stats.gotV, stats.gotC))
        local me = try(function() return game.pawn:K2_GetActorLocation() end)
        log(string.format("   moi : %s | autre joueur : %s (reçu il y a %ss)",
            me and string.format("%.0f %.0f %.0f", me.X, me.Y, me.Z) or "?",
            rp and string.format("%.0f %.0f %.0f", rp.X, rp.Y, rp.Z) or "rien reçu",
            remote.time > 0 and tostring(now() - remote.time) or "-"))
    end
    local f = io.open(OUT_FILE, "w")
    if f then f:write(data) f:close() end

    -- Le fantôme suit la position reçue de l'autre joueur (sauf pendant le test F3)
    if markerOn and remote.player and remote.player.X and now() >= testUntil then
        placeGhost(remote.player)
    end
end

local busy = false
LoopAsync(cfg.TICK_MS, function()
    if enabled and not busy then
        busy = true
        ExecuteInGameThread(function()
            local ok, err = pcall(syncStep)
            if not ok then log("Erreur : " .. tostring(err)) end
            busy = false
        end)
    end
    return false
end)

----------------------------------------------------------------------
-- TOUCHES
----------------------------------------------------------------------
local function writeReport()
    if not checkReady() and not valid(game.pawn) then log("Entre dans une nuit avant F5") return end
    discover()
    local lines = { "FredbearCoop v6 - rapport du " .. os.date(), "Rôle : " .. cfg.ROLE,
        "Map : " .. tostring(game.map), "Joueur : " .. fullName(game.pawn), "",
        "=== Objets synchronisés ===" }
    local names = {}
    for n in pairs(tracked) do names[#names + 1] = n end
    table.sort(names)
    for _, n in ipairs(names) do
        local e = tracked[n]
        lines[#lines + 1] = string.format("[%s] classe=%s pawn=%s bouge=%s", n, e.cls, tostring(e.isPawn), tostring(e.moves))
        for _, pr in ipairs(e.props) do
            lines[#lines + 1] = "    " .. pr.kind .. " " .. pr.name .. " = " .. tostring(fmt(getVar(e.obj, pr.name)))
        end
    end
    lines[#lines + 1] = ""
    lines[#lines + 1] = "=== Classes Blueprint présentes ==="
    local seen = {}
    for _, a in ipairs(try(function() return FindAllOf("Actor") end) or {}) do
        if valid(a) then
            local c = className(a)
            if c:sub(-2) == "_C" and not seen[c] then
                seen[c] = true
                lines[#lines + 1] = "  " .. c .. "  (ex : " .. tostring(nameOf(a)) .. ")"
            end
        end
    end
    local text = table.concat(lines, "\n")
    for _, path in ipairs({ DESKTOP .. "\\fredbear_coop_rapport.txt", TMP .. "\\fredbear_coop_rapport.txt" }) do
        local f = io.open(path, "w")
        if f then f:write(text) f:close() log("Rapport écrit : " .. path) return end
    end
end

local function consoleCommand(cmd)
    local ksl = cls("/Script/Engine.Default__KismetSystemLibrary")
    if not valid(game.pc) or not valid(ksl) then log("Impossible : entre d'abord dans une nuit") return end
    log("Commande : " .. cmd)
    pcall(function() ksl:ExecuteConsoleCommand(game.pc, cmd, game.pc) end)
end

local function bind(key, fn)
    if not cfg.KEYBINDS then return end
    pcall(function()
        RegisterKeyBind(key, function()
            ExecuteInGameThread(function()
                local ok, err = pcall(fn)
                if not ok then log("Erreur touche : " .. tostring(err)) end
            end)
        end)
    end)
end

bind(Key.F3, function()
    local l = try(function() return game.pawn:K2_GetActorLocation() end)
    if not l then log("Entre dans une nuit avant F3") return end
    local yaw = try(function() return game.pc.ControlRotation.Yaw end) or 0
    local r = math.rad(yaw)
    local at = { X = l.X + math.cos(r) * 200, Y = l.Y + math.sin(r) * 200, Z = l.Z }
    testUntil = now() + 4
    if placeGhost(at) then
        log("Test : le fantôme est devant toi pendant 4 secondes")
    else
        log("Le fantôme n'a pas pu être créé")
    end
end)
bind(Key.F4, function()
    markerOn = not markerOn
    log(markerOn and "Fantôme de l'autre joueur : ON" or "Fantôme de l'autre joueur : OFF")
    for _, a in pairs({ ghost.body, ghost.light }) do
        if valid(a) then pcall(function() a:SetActorHiddenInGame(not markerOn) end) end
    end
end)

bind(Key.F5, writeReport)
bind(Key.F6, function()
    local count = 0
    for _ in pairs(tracked) do count = count + 1 end
    local age = remote.time > 0 and (now() - remote.time) or -1
    log(string.format("Rôle=%s | map=%s | nuit prête=%s | objets=%d | dernier paquet il y a %ds",
        cfg.ROLE, tostring(game.map), tostring(game.ready), count, age))
    log(string.format("Envoyés : pos=%d var=%d | Reçus : pos=%d var=%d chg=%d",
        stats.sentA, stats.sentV, stats.gotA, stats.gotV, stats.gotC))
end)
bind(Key.F7, function()
    enabled = not enabled
    log(enabled and "Synchro ACTIVÉE" or "Synchro DÉSACTIVÉE")
end)
bind(Key.F8, function()
    if not IS_HOST then log("F8 = hôte seulement") return end
    if not game.map then log("Entre d'abord dans une nuit") return end
    consoleCommand("open " .. game.map .. "?listen")
end)
bind(Key.F9, function()
    if IS_HOST then log("F9 = client seulement") return end
    consoleCommand("open " .. cfg.HOST_IP)
end)

log("v6 chargée. Rôle = " .. cfg.ROLE .. ". J'attends une nuit pour démarrer.")
