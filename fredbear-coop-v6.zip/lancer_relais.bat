@echo off
cd /d "%~dp0"
set /p IP=Tape l IP Radmin de l autre PC puis Entree : 
where py 1>NUL 2>NUL
if %errorlevel%==0 (
  py relay.py %IP%
) else (
  python relay.py %IP%
)
pause
