"""
relay.py - pont réseau du mod FredbearCoop (v2)

Chaque joueur le lance sur son PC, en même temps que le jeu, avec l'IP de L'AUTRE :
    python relay.py 26.12.34.56

  - Il lit %TEMP%\\fredbear_coop_local.txt (écrit par le mod) et l'envoie en UDP,
    compressé, au PC de l'autre joueur.
  - Il reçoit les données de l'autre et les écrit dans
    %TEMP%\\fredbear_coop_remote.txt (lu par le mod).

Port par défaut : 7780 (UDP). Le 7777 reste libre pour le serveur Unreal (F8/F9).
Aucune bibliothèque à installer : Python 3.8+ suffit.
"""

import argparse
import os
import socket
import tempfile
import time
import zlib

TMP = os.environ.get("TEMP") or os.environ.get("TMP") or tempfile.gettempdir()
LOCAL_FILE = os.path.join(TMP, "fredbear_coop_local.txt")
REMOTE_FILE = os.path.join(TMP, "fredbear_coop_remote.txt")
MAGIC = b"FBC2"
MAX_UDP = 65000


def read_local():
    """Renvoie le message complet du mod, ou None s'il est en cours d'écriture."""
    try:
        with open(LOCAL_FILE, "rb") as f:
            data = f.read()
    except OSError:
        return None
    if not data.startswith(b"S\t") or not data.endswith(b"\nE"):
        return None
    return data


def write_remote(data):
    tmp_path = REMOTE_FILE + ".tmp"
    with open(tmp_path, "wb") as f:
        f.write(data)
    # Remplacement atomique : le jeu ne lit jamais un fichier à moitié écrit.
    # Sous Windows ça échoue si le jeu lit à cet instant précis : on réessaie.
    for _ in range(10):
        try:
            os.replace(tmp_path, REMOTE_FILE)
            return True
        except PermissionError:
            time.sleep(0.003)
    return False


def main():
    ap = argparse.ArgumentParser(description="Pont réseau FredbearCoop")
    ap.add_argument("peer_ip", help="IP du PC de l'autre joueur (Radmin VPN / Tailscale / LAN)")
    ap.add_argument("--port", type=int, default=7780, help="port UDP (le même des deux côtés)")
    ap.add_argument("--rate", type=float, default=20.0, help="envois par seconde")
    args = ap.parse_args()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("0.0.0.0", args.port))
    sock.setblocking(False)
    peer = (args.peer_ip, args.port)

    print(f"[relay] Écoute sur UDP {args.port}, envoi vers {peer[0]}:{peer[1]}")
    print(f"[relay] Envoi     : {LOCAL_FILE}")
    print(f"[relay] Réception : {REMOTE_FILE}")
    print("[relay] Ctrl+C pour arrêter.\n")

    interval = 1.0 / args.rate
    last_rx = 0.0
    last_status = 0.0
    connected = False
    sent = received = 0
    last_size = 0
    warned_big = False

    while True:
        t0 = time.time()

        data = read_local()
        if data:
            packet = MAGIC + zlib.compress(data, 6)
            if len(packet) > MAX_UDP:
                if not warned_big:
                    print(f"[relay] Message trop gros ({len(packet)} octets) : retire des mots-clés dans config.lua")
                    warned_big = True
            else:
                try:
                    sock.sendto(packet, peer)
                    sent += 1
                    last_size = len(packet)
                except OSError as e:
                    print(f"[relay] Erreur d'envoi : {e}")

        newest = None
        while True:
            try:
                pkt, _ = sock.recvfrom(MAX_UDP + 100)
            except (BlockingIOError, ConnectionResetError):
                break
            if pkt.startswith(MAGIC):
                try:
                    newest = zlib.decompress(pkt[len(MAGIC):])
                except zlib.error:
                    pass
        if newest:
            if write_remote(newest):
                received += 1
                last_rx = time.time()
                if not connected:
                    role = newest.split(b"\n", 1)[0].split(b"\t")[-1].decode("ascii", "ignore")
                    print(f"[relay] Connecté ! L'autre joueur est en mode '{role}'.")
                    connected = True

        if connected and time.time() - last_rx > 3:
            print("[relay] Plus de nouvelles de l'autre joueur...")
            connected = False

        if time.time() - last_status > 5:
            last_status = time.time()
            env = f"{sent} paquets ({last_size} octets)" if sent else "rien (jeu + mod lancés ? tu es dans une nuit ?)"
            rec = f"{received} paquets" if connected else "en attente de l'autre joueur"
            print(f"[relay] envoyés : {env} | reçus : {rec}")

        time.sleep(max(0.0, interval - (time.time() - t0)))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[relay] Arrêté.")
