# FredbearCoop v6 : jouer à deux à Those Nights at Fredbear's

## Ce que fait le mod

Le mod essaie **deux méthodes** en même temps. Garde celle qui marche le mieux.

**Méthode 1 : le serveur Unreal intégré (touches F8 / F9)**
Unreal Engine a le multijoueur intégré, même dans un jeu solo. L'hôte relance la map en mode serveur, le client s'y connecte. Si le jeu l'accepte, vous êtes **dans la même partie** et vous voyez vos personnages. Je pense que c'est ce que tu avais réussi avant.

**Méthode 2 : la synchro du mod (automatique, avec `relay.py`)**
Chacun lance sa propre nuit, et **celle de l'hôte fait foi** :
- les animatroniques du client se placent là où sont ceux de l'hôte, et leur IA locale est coupée ;
- les variables du jeu (batterie, heure, portes, lumières...) sont copiées de l'hôte vers le client ;
- quand le client ferme une porte ou allume une lumière, l'info part chez l'hôte ;
- chacun voit l'autre joueur sous forme d'une **lumière verte**.

Le mod trouve tout seul les objets du jeu à partir de mots-clés (`fred`, `door`, `power`, `battery`, `night`...). Tu n'as pas besoin de connaître leurs noms.

## Ce qu'il faut (sur les DEUX PC)
- Le jeu, **la même version** des deux côtés.
- **UE4SS** : https://github.com/UE4SS-RE/RE-UE4SS/releases (le zip `UE4SS_v3.x.x.zip`, pas `zDEV`).
- **Python 3** : https://www.python.org/downloads/ (coche **"Add Python to PATH"**).
- Si vous n'êtes pas chez la même personne : **Radmin VPN** (gratuit). L'un crée un réseau, l'autre le rejoint. Chacun note **l'IP Radmin de l'autre** (elle commence par `26.`).

## Installation

### 1. UE4SS
1. Dans le dossier du jeu, trouve le dossier `...\Binaries\Win64\` (celui où il y a un `.exe` qui finit souvent par `-Win64-Shipping.exe`).
2. Dézippe UE4SS **dedans**. Tu dois voir `dwmapi.dll` et un dossier `ue4ss` à côté du `.exe`.
3. Ouvre `ue4ss\UE4SS-settings.ini` et mets `ConsoleEnabled = 1`.
4. Lance le jeu une fois : une fenêtre console noire doit s'ouvrir.

### 2. Le mod
1. Copie le dossier `FredbearCoop` dans `Win64\ue4ss\Mods\` (anciennes versions d'UE4SS : `Win64\Mods\`).
2. Ouvre `Mods\mods.txt` et ajoute la ligne `FredbearCoop : 1` au-dessus de `Keybinds : 1`.
3. Ouvre `FredbearCoop\Scripts\config.lua` avec le Bloc-notes :
   - chez **l'hôte** : `ROLE = "host",`
   - chez **le client** : `ROLE = "client",` et `HOST_IP = "26.xx.xx.xx",` (l'IP de l'hôte)
4. Lance le jeu. Dans la console, tu dois voir `[FredbearCoop] v2 chargé. Rôle = ...`

### 3. Pare-feu
La première fois, Windows demande d'autoriser le jeu et Python : clique **Autoriser** (coche réseaux privés et publics). Si rien ne marche, autorise à la main les ports UDP **7777** (serveur Unreal) et **7780** (relais).

## Jouer

### Méthode 1 : serveur Unreal
1. L'hôte entre dans une nuit, puis appuie sur **F8**. La map se recharge.
2. Le client, depuis le menu ou n'importe où dans le jeu, appuie sur **F9**.
3. Si le client arrive dans la map de l'hôte, c'est gagné. Si son écran reste noir ou s'il revient au menu, le jeu bloque cette méthode : passe à la méthode 2.

### Méthode 2 : synchro du mod
1. Les deux entrent **dans la même nuit**. L'hôte la lance en premier.
2. Sur chaque PC, ouvre une invite de commande dans le dossier de `relay.py` et tape, avec l'IP **de l'autre** :
   ```
   python relay.py 26.xx.xx.xx
   ```
3. Quand le relais affiche `Connecté !`, la synchro marche. Appuie sur **F6** pour voir combien d'objets sont synchronisés.

### Les touches
| Touche | Action |
|---|---|
| F3 | Test : fait apparaître le fantôme (corps gris + lumière verte) devant toi pendant 4 s |
| F4 | Fantôme de l'autre joueur ON / OFF (n'y touche pas si tu ne veux pas le cacher) |
| F5 | Crée `fredbear_coop_rapport.txt` sur le Bureau : la liste des objets trouvés dans le jeu |
| F6 | Affiche l'état de la synchro dans la console |
| F7 | Coupe / remet la synchro |
| F8 | Hôte : ouvre la map en serveur Unreal |
| F9 | Client : rejoint le serveur Unreal de l'hôte |

## Si ça ne marche pas
| Problème | Solution |
|---|---|
| Pas de `v2 chargé` dans la console | Le mod n'est pas dans le bon dossier, ou la ligne manque dans `mods.txt`. |
| Le relais dit `envoyés : rien` | Tu es dans un menu, ou le mod ne tourne pas. Entre dans une nuit. |
| Le relais reste `en attente` | Mauvaise IP, pare-feu, ou l'autre n'a pas lancé `relay.py`. Testez `ping 26.xx.xx.xx`. |
| F6 dit `objets suivis=0` | Le jeu utilise d'autres noms. Appuie sur **F5** et envoie-moi le rapport : j'ajouterai les bons mots-clés. |
| Les animatroniques bougent mais les portes s'affichent mal | La variable change, mais l'animation de la porte ne se déclenche pas. Envoie-moi le rapport F5 : je brancherai l'animation directement. |
| Le client se fait jumpscare tout seul | Son IA locale n'a pas pu être coupée. Envoie-moi le rapport F5. |

## Ce que je n'ai pas pu vérifier
J'ai testé le code avec une simulation du jeu : les positions, la batterie, l'heure et les portes passent bien de l'hôte au client, et les portes fermées par le client remontent chez l'hôte. Mais je n'ai pas le jeu, donc je ne sais pas encore quels noms il utilise exactement, ni s'il accepte le serveur Unreal. **Le rapport F5 règle ça** : envoie-le-moi après ta première partie et j'ajusterai le mod pour ce jeu précis.

## Si le jeu plante ("Fatal error")

**1. Vérifie que mon mod se charge.** Dans la fenêtre noire UE4SS, cherche `[FredbearCoop] v6 chargée`. Si cette ligne n'est pas là, le mod n'est pas chargé : le dossier doit être exactement `ue4ss\Mods\FredbearCoop\Scripts\main.lua` (pas un dossier `FredbearCoop` dans un autre dossier `FredbearCoop`).

**2. Coupe les mods en trop.** Dans `ue4ss\Mods\mods.txt`, mets :
```
SplitScreenMod : 0
LineTraceMod : 0
ActorDumperMod : 0
jsbLuaProfilerMod : 0
KismetDebugger : 0
EventViewer : 0
FredbearCoop : 1
```
Coupe aussi le mod de Gemini (celui qui écrit `coop_my_pos.txt`). Si un de ces dossiers contient un fichier `enabled.txt`, supprime-le, sinon le mod se lance quand même.

**3. Lance une nuit.**
- Ça marche : un des mods coupés faisait planter. Ne rallume pas `SplitScreenMod`.
- Ça plante encore : mets aussi `FredbearCoop : 0` et relance. Si ça plante toujours, ce n'est pas mon mod. Si ça ne plante plus, ouvre `config.lua`, mets tous les interrupteurs à `false`, puis rallume-les un par un pour trouver lequel pose problème.

À chaque crash, envoie-moi les dernières lignes qui commencent par `[FredbearCoop]` dans `UE4SS.log` : elles disent ce que le mod faisait juste avant.
